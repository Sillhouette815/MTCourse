func_Check()				函数，检验解的有效性
func_GenerateLinearEquation()		函数，随机生成相容/矛盾线性方程组
func_MyFR()				函数，矩阵满秩分解
func_ShowResult()			函数，显示线性方程组
func_Iszero()				函数，检验矩阵在一定容县内是否为零矩阵


MPTest					测试程序